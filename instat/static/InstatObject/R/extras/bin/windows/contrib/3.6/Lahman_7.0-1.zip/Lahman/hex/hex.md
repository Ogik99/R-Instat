## The hex sticker for the Lahman package.

